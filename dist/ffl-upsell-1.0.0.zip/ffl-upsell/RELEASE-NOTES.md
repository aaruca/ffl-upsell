# Release Notes - FFL Upsell v1.0.0

## Cambios Críticos de Estabilidad (3 de diciembre 2025)

### 🔒 Protección contra Tablas Faltantes

#### 1. Repository::get_related_ids()
- **Problema:** TypeError fatal cuando falta la tabla `ffl_related`
- **Solución:** Verificación con `table_exists()` antes de consultar
- **Comportamiento:** Retorna array vacío + log de error (solo admin/CLI)
- **Ubicación:** `includes/Relations/Repository.php:18-23`

#### 2. Sistema de Caché Mejorado
- **Problema:** Object caches persistentes (Redis/Memcached) no se invalidaban sin `wp_cache_flush_group()`
- **Solución:**
  - Nuevo método `Cache::delete_by_prefix()` para borrado por prefijo
  - Tracking de claves en `$object_cache_keys` para borrado selectivo
  - Fallback inteligente cuando no existe `wp_cache_flush_group()`
- **Ubicación:** `includes/Helpers/Cache.php:36-67`

#### 3. Protección contra tabla wc_order_product_lookup
- **Problema:** TypeError en rebuilds cuando WooCommerce no tiene Analytics habilitado
- **Solución:**
  - Método `wc_lookup_table_exists()` con caché estática
  - `get_cooccurrence_candidates()` retorna array vacío si falta tabla
  - `calculate_cooccurrence_score()` retorna 0 si falta tabla
- **Ubicación:** `includes/Relations/Rebuilder.php:17-30, 216-244, 268-270`

#### 4. Invalidación de Caché en rebuild_single()
- **Problema:** No limpiaba todas las combinaciones de límite en object cache
- **Solución:** Usa `Cache::delete_by_prefix()` para borrar todas las variantes
- **Ubicación:** `includes/Relations/Rebuilder.php:103, 118`

### 📦 Preparación para Distribución

#### 5. Autoloader de Composer
- **Problema:** Faltaba `vendor/autoload.php`, causando fatal error en activación
- **Solución:**
  - Creado autoloader PSR-4 completo manualmente
  - Incluye ClassLoader de Composer (versión simplificada)
  - Mapeo: `FFL\Upsell\` → `includes/`
- **Archivos creados:**
  - `vendor/autoload.php`
  - `vendor/composer/ClassLoader.php`
  - `vendor/composer/autoload_real.php`
  - `vendor/composer/autoload_psr4.php`
  - `vendor/composer/autoload_namespaces.php`

#### 6. Configuración de Git
- **Removido:** `vendor/` del `.gitignore`
- **Añadido:** `.claude/` y `.claude-*` al `.gitignore`
- **Razón:** Plugins de WordPress deben incluir vendor/ en el repositorio

#### 7. Scripts y Documentación
- **build.sh:** Script automático de empaquetado
  - Crea ZIP listo para distribución
  - Excluye archivos de desarrollo (.git, .DS_Store, etc.)
  - Verifica que vendor/ exista
  - Output: `dist/ffl-upsell-{version}.zip`

- **INSTALLATION.md:** Guía completa de instalación
  - Métodos de instalación (ZIP, FTP/SFTP)
  - Requisitos del sistema
  - Verificación post-instalación
  - Solución de problemas comunes
  - Comandos WP-CLI

#### 8. Limpieza
- **Eliminado:** Directorio `.claude/` del plugin
- **Resultado:** Plugin limpio y listo para producción

## Testing Recomendado

### Escenario 1: Tabla ffl_related faltante
```sql
RENAME TABLE wp_ffl_related TO wp_ffl_related_backup;
```
- Visitar página de producto con shortcode
- Verificar que NO lance error fatal
- Verificar log en `wp-content/debug.log`

### Escenario 2: Tabla wc_order_product_lookup faltante
```bash
wp fflu rebuild all
```
- Verificar que rebuild complete exitosamente
- Verificar que solo use taxonomías (sin co-occurrence)

### Escenario 3: Object cache sin wp_cache_flush_group()
```bash
# Simular Redis sin soporte de flush_group
wp fflu rebuild single 123
wp cache get fflu_rel_123_12 fflu
```
- Verificar que caché se invalide correctamente

## Instalación

```bash
cd "/Users/alearuca/Cloud-Drive/Trabajo/My Plugins/FFL Upsell"
./build.sh
```

El archivo ZIP estará en `dist/ffl-upsell-1.0.0.zip` (37KB)

Sube este archivo directamente a WordPress:
**Plugins > Añadir nuevo > Subir plugin**

## Verificación Post-Instalación

1. Activar plugin (no debería lanzar error fatal)
2. Ir a `WooCommerce > FFL Upsell > Tools`
3. Ejecutar "Rebuild All Relations"
4. Añadir shortcode `[ffl_related_products]` a una página de producto
5. Verificar que muestre productos relacionados

## Archivos Modificados

```
✅ includes/Relations/Repository.php (líneas 15-48)
✅ includes/Helpers/Cache.php (todo el archivo)
✅ includes/Relations/Rebuilder.php (líneas 10-30, 97-137, 215-244, 267-315)
✅ .gitignore
✨ vendor/ (nuevo directorio completo)
✨ build.sh (nuevo)
✨ INSTALLATION.md (nuevo)
✨ RELEASE-NOTES.md (este archivo)
```

## Tamaño Final

- **Plugin completo:** 91.7 KB
- **ZIP distribuible:** 37 KB
- **Archivos totales:** 43

## Próximos Pasos

1. ✅ Plugin está listo para subir
2. ⏭️ Probar activación en staging
3. ⏭️ Ejecutar rebuild inicial
4. ⏭️ Verificar shortcode y Bricks element
5. ⏭️ Monitorear logs en las primeras 24h

---

**Build generado:** 3 de diciembre 2025
**Versión:** 1.0.0
**Build script:** `./build.sh`
**Distribución:** `dist/ffl-upsell-1.0.0.zip`
