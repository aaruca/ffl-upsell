<?php

namespace FFL\Upsell\Admin;

use FFL\Upsell\Relations\Rebuilder;

defined('ABSPATH') || exit;

class SettingsPage {
    private Rebuilder $rebuilder;

    public function __construct(Rebuilder $rebuilder) {
        $this->rebuilder = $rebuilder;
    }

    public function register_menu(): void {
        add_submenu_page(
            'woocommerce',
            __('FFL Upsell Settings', 'ffl-upsell'),
            __('FFL Upsell', 'ffl-upsell'),
            'manage_woocommerce',
            'ffl-upsell-settings',
            [$this, 'render_page']
        );
    }

    public function register_settings(): void {
        register_setting('fflu_settings', 'fflu_limit_per_product', [
            'type' => 'integer',
            'default' => 20,
            'sanitize_callback' => 'absint',
        ]);

        register_setting('fflu_settings', 'fflu_weight_cat_tag', [
            'type' => 'number',
            'default' => 0.6,
            'sanitize_callback' => 'floatval',
        ]);

        register_setting('fflu_settings', 'fflu_weight_cooccur', [
            'type' => 'number',
            'default' => 0.4,
            'sanitize_callback' => 'floatval',
        ]);

        register_setting('fflu_settings', 'fflu_cache_ttl', [
            'type' => 'integer',
            'default' => 10,
            'sanitize_callback' => 'absint',
        ]);

        register_setting('fflu_settings', 'fflu_batch_size', [
            'type' => 'integer',
            'default' => 500,
            'sanitize_callback' => 'absint',
        ]);

        register_setting('fflu_settings', 'fflu_cron_enabled', [
            'type' => 'boolean',
            'default' => 1,
            'sanitize_callback' => function ($value) {
                $new_value = $value ? 1 : 0;
                $old_value = get_option('fflu_cron_enabled', 1);

                if ($new_value !== $old_value) {
                    if ($new_value) {
                        if (!wp_next_scheduled('fflu_daily_rebuild')) {
                            wp_schedule_event(time(), 'daily', 'fflu_daily_rebuild');
                        }
                    } else {
                        $timestamp = wp_next_scheduled('fflu_daily_rebuild');
                        if ($timestamp) {
                            wp_unschedule_event($timestamp, 'fflu_daily_rebuild');
                        }
                    }
                }

                return $new_value;
            },
        ]);

        add_settings_section(
            'fflu_main_section',
            __('Relation Builder Settings', 'ffl-upsell'),
            [$this, 'render_section_description'],
            'fflu_settings'
        );

        add_settings_field(
            'fflu_limit_per_product',
            __('Relations per Product', 'ffl-upsell'),
            [$this, 'render_limit_field'],
            'fflu_settings',
            'fflu_main_section'
        );

        add_settings_field(
            'fflu_weight_cat_tag',
            __('Category/Tag Weight', 'ffl-upsell'),
            [$this, 'render_cat_tag_weight_field'],
            'fflu_settings',
            'fflu_main_section'
        );

        add_settings_field(
            'fflu_weight_cooccur',
            __('Co-occurrence Weight', 'ffl-upsell'),
            [$this, 'render_cooccur_weight_field'],
            'fflu_settings',
            'fflu_main_section'
        );

        add_settings_field(
            'fflu_cache_ttl',
            __('Cache TTL (minutes)', 'ffl-upsell'),
            [$this, 'render_cache_ttl_field'],
            'fflu_settings',
            'fflu_main_section'
        );

        add_settings_field(
            'fflu_batch_size',
            __('Batch Size', 'ffl-upsell'),
            [$this, 'render_batch_size_field'],
            'fflu_settings',
            'fflu_main_section'
        );

        add_settings_field(
            'fflu_cron_enabled',
            __('Enable Daily Cron', 'ffl-upsell'),
            [$this, 'render_cron_enabled_field'],
            'fflu_settings',
            'fflu_main_section'
        );
    }

    public function render_page(): void {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $this->handle_rebuild_action();

        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <form method="post" action="options.php">
                <?php
                settings_fields('fflu_settings');
                do_settings_sections('fflu_settings');
                submit_button(__('Save Settings', 'ffl-upsell'));
                ?>
            </form>

            <hr>

            <h2><?php esc_html_e('Rebuild Relations', 'ffl-upsell'); ?></h2>
            <p><?php esc_html_e('Trigger a manual rebuild of all product relations. This may take several minutes for large catalogs.', 'ffl-upsell'); ?></p>

            <form method="post" action="">
                <?php wp_nonce_field('fflu_rebuild_action', 'fflu_rebuild_nonce'); ?>
                <p>
                    <button type="submit" name="fflu_rebuild" class="button button-primary">
                        <?php esc_html_e('Rebuild Relations Now', 'ffl-upsell'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    private function handle_rebuild_action(): void {
        if (!isset($_POST['fflu_rebuild'])) {
            return;
        }

        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        if (!isset($_POST['fflu_rebuild_nonce']) || !wp_verify_nonce($_POST['fflu_rebuild_nonce'], 'fflu_rebuild_action')) {
            add_settings_error(
                'fflu_messages',
                'fflu_rebuild_error',
                __('Security check failed.', 'ffl-upsell'),
                'error'
            );
            return;
        }

        $result = $this->rebuilder->rebuild_all();

        add_settings_error(
            'fflu_messages',
            'fflu_rebuild_success',
            sprintf(
                __('Rebuild completed! Processed %d products, created %d relations.', 'ffl-upsell'),
                $result['products_processed'],
                $result['total_relations']
            ),
            'success'
        );

        settings_errors('fflu_messages');
    }

    public function render_section_description(): void {
        echo '<p>' . esc_html__('Configure how related products are calculated and cached.', 'ffl-upsell') . '</p>';
    }

    public function render_limit_field(): void {
        $value = get_option('fflu_limit_per_product', 20);
        echo '<input type="number" name="fflu_limit_per_product" value="' . esc_attr($value) . '" min="1" max="100" />';
        echo '<p class="description">' . esc_html__('Maximum number of related products to store per product.', 'ffl-upsell') . '</p>';
    }

    public function render_cat_tag_weight_field(): void {
        $value = get_option('fflu_weight_cat_tag', 0.6);
        echo '<input type="number" name="fflu_weight_cat_tag" value="' . esc_attr($value) . '" min="0" max="1" step="0.1" />';
        echo '<p class="description">' . esc_html__('Weight for category/tag similarity (0-1).', 'ffl-upsell') . '</p>';
    }

    public function render_cooccur_weight_field(): void {
        $value = get_option('fflu_weight_cooccur', 0.4);
        echo '<input type="number" name="fflu_weight_cooccur" value="' . esc_attr($value) . '" min="0" max="1" step="0.1" />';
        echo '<p class="description">' . esc_html__('Weight for order co-occurrence (0-1).', 'ffl-upsell') . '</p>';
    }

    public function render_cache_ttl_field(): void {
        $value = get_option('fflu_cache_ttl', 10);
        echo '<input type="number" name="fflu_cache_ttl" value="' . esc_attr($value) . '" min="1" max="1440" />';
        echo '<p class="description">' . esc_html__('How long to cache related product queries (in minutes).', 'ffl-upsell') . '</p>';
    }

    public function render_batch_size_field(): void {
        $value = get_option('fflu_batch_size', 500);
        echo '<input type="number" name="fflu_batch_size" value="' . esc_attr($value) . '" min="50" max="2000" />';
        echo '<p class="description">' . esc_html__('Number of products to process per batch during rebuild.', 'ffl-upsell') . '</p>';
    }

    public function render_cron_enabled_field(): void {
        $value = get_option('fflu_cron_enabled', 1);
        echo '<input type="checkbox" name="fflu_cron_enabled" value="1" ' . checked($value, 1, false) . ' />';
        echo '<label>' . esc_html__('Enable automatic daily rebuild via WP-Cron.', 'ffl-upsell') . '</label>';
    }
}
