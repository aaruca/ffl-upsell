<?php

namespace FFL\Upsell\Runtime;

use FFL\Upsell\Relations\Repository;
use FFL\Upsell\Helpers\Cache;

defined('ABSPATH') || exit;

class RelatedService {
    private Repository $repository;

    public function __construct(Repository $repository) {
        $this->repository = $repository;
    }

    public function get_related_ids(int $product_id, int $limit = 12): array {
        $cache_key = "fflu_rel_{$product_id}_{$limit}";
        $cache_ttl = (int) get_option('fflu_cache_ttl', 10);
        $cache_ttl = apply_filters('fflu_cache_ttl', $cache_ttl, $product_id);

        $cached = Cache::get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $ids = $this->repository->get_related_ids($product_id, $limit);

        $ids = array_filter($ids, function ($id) {
            $product = wc_get_product($id);
            return $product && $product->is_visible() && $product->is_in_stock();
        });

        $ids = array_values($ids);

        $ids = apply_filters('fflu_related_ids', $ids, $product_id, $limit);

        Cache::set($cache_key, $ids, $cache_ttl * MINUTE_IN_SECONDS);

        return $ids;
    }

    public function override_wc_related(): void {
        add_filter('woocommerce_related_products', [$this, 'filter_wc_related_products'], 10, 3);
    }

    public function filter_wc_related_products(array $related_posts, int $product_id, array $args): array {
        $limit = $args['limit'] ?? 12;
        $related_ids = $this->get_related_ids($product_id, $limit);

        if (empty($related_ids)) {
            return $related_posts;
        }

        return $related_ids;
    }
}
