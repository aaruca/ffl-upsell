<?php

namespace FFL\Upsell\Bricks;

use FFL\Upsell\Runtime\RelatedService;

defined('ABSPATH') || exit;

class QueryProvider {
    private RelatedService $related_service;

    public function __construct(RelatedService $related_service) {
        $this->related_service = $related_service;
    }

    public function register(): void {
        add_filter('bricks/query/loop_object_types', [$this, 'add_query_provider']);
        add_filter('bricks/query/controls', [$this, 'add_query_controls'], 10, 2);
        add_filter('bricks/query/run', [$this, 'run_query'], 10, 2);
    }

    public function add_query_provider(array $object_types): array {
        $object_types['fflu_related'] = __('FFL Related Products', 'ffl-upsell');
        return $object_types;
    }

    public function add_query_controls(array $controls, string $object_type): array {
        if ($object_type !== 'fflu_related') {
            return $controls;
        }

        $controls['fflu_limit'] = [
            'label' => __('Limit', 'ffl-upsell'),
            'type' => 'number',
            'min' => 1,
            'max' => 50,
            'default' => 8,
            'description' => __('Number of related products to display', 'ffl-upsell'),
        ];

        $controls['fflu_use_current'] = [
            'label' => __('Use Current Product', 'ffl-upsell'),
            'type' => 'checkbox',
            'default' => true,
            'description' => __('Get related products for the current product in the loop', 'ffl-upsell'),
        ];

        $controls['fflu_product_id'] = [
            'label' => __('Product ID', 'ffl-upsell'),
            'type' => 'number',
            'min' => 0,
            'default' => 0,
            'required' => ['fflu_use_current', '=', false],
            'description' => __('Specific product ID (used when "Use Current Product" is disabled)', 'ffl-upsell'),
        ];

        return $controls;
    }

    public function run_query(array $results, \Bricks\Query $query): array {
        $query_vars = $query->settings;

        if (!isset($query_vars['objectType']) || $query_vars['objectType'] !== 'fflu_related') {
            return $results;
        }

        $limit = isset($query_vars['fflu_limit']) ? absint($query_vars['fflu_limit']) : 8;
        $use_current = isset($query_vars['fflu_use_current']) ? (bool) $query_vars['fflu_use_current'] : true;
        $product_id = isset($query_vars['fflu_product_id']) ? absint($query_vars['fflu_product_id']) : 0;

        if ($use_current) {
            $product_id = $this->get_current_product_id();
        }

        if ($product_id === 0) {
            return [];
        }

        $related_ids = $this->related_service->get_related_ids($product_id, $limit);

        if (empty($related_ids)) {
            return [];
        }

        $args = [
            'include' => $related_ids,
            'limit' => $limit,
            'orderby' => 'post__in',
        ];

        $products = wc_get_products($args);

        $results = [];

        foreach ($products as $product) {
            $results[] = (object) [
                'ID' => $product->get_id(),
                'post_type' => 'product',
            ];
        }

        return $results;
    }

    private function get_current_product_id(): int {
        global $product, $post;

        if ($product && is_a($product, 'WC_Product')) {
            return $product->get_id();
        }

        if ($post && $post->post_type === 'product') {
            return $post->ID;
        }

        if (is_singular('product')) {
            return get_the_ID();
        }

        return 0;
    }
}
