<?php

namespace FFL\Upsell\Bricks;

use FFL\Upsell\Runtime\RelatedService;
use FFL\Upsell\Helpers\Products;

defined('ABSPATH') || exit;

class Element extends \Bricks\Element {
    public $category = 'woocommerce';
    public $name = 'fflu-related';
    public $icon = 'ti-layout-grid3';
    public $css_selector = '.fflu-bricks-element';
    public $scripts = [];

    private static ?RelatedService $related_service = null;

    public function __construct($related_service = null) {
        if ($related_service !== null) {
            self::$related_service = $related_service;
        }
        parent::__construct();
    }

    public static function register(RelatedService $related_service): void {
        self::$related_service = $related_service;
        \Bricks\Elements::register_element(__FILE__, __CLASS__);
    }

    public function get_label(): string {
        return __('FFL Related Products', 'ffl-upsell');
    }

    public function set_controls(): void {
        $this->controls['title'] = [
            'tab' => 'content',
            'label' => __('Title', 'ffl-upsell'),
            'type' => 'text',
            'default' => __('Related Products', 'ffl-upsell'),
        ];

        $this->controls['limit'] = [
            'tab' => 'content',
            'label' => __('Limit', 'ffl-upsell'),
            'type' => 'number',
            'default' => 8,
            'min' => 1,
            'max' => 50,
        ];

        $this->controls['product_id'] = [
            'tab' => 'content',
            'label' => __('Product ID', 'ffl-upsell'),
            'type' => 'number',
            'description' => __('Leave empty to use current product', 'ffl-upsell'),
            'default' => 0,
        ];

        $this->controls['layout'] = [
            'tab' => 'content',
            'label' => __('Layout', 'ffl-upsell'),
            'type' => 'select',
            'options' => [
                'grid' => __('Grid', 'ffl-upsell'),
                'list' => __('List', 'ffl-upsell'),
            ],
            'default' => 'grid',
        ];

        $this->controls['columns'] = [
            'tab' => 'content',
            'label' => __('Columns', 'ffl-upsell'),
            'type' => 'number',
            'default' => 4,
            'min' => 1,
            'max' => 6,
            'required' => ['layout', '=', 'grid'],
        ];

        $this->controls['show_price'] = [
            'tab' => 'content',
            'label' => __('Show Price', 'ffl-upsell'),
            'type' => 'checkbox',
            'default' => true,
        ];

        $this->controls['show_add_to_cart'] = [
            'tab' => 'content',
            'label' => __('Show Add to Cart', 'ffl-upsell'),
            'type' => 'checkbox',
            'default' => true,
        ];

        $this->controls['gap'] = [
            'tab' => 'content',
            'label' => __('Gap', 'ffl-upsell'),
            'type' => 'dimensions',
            'css' => [
                [
                    'property' => 'gap',
                    'selector' => '.fflu-bricks-products',
                ],
            ],
        ];
    }

    public function render(): void {
        $settings = $this->settings;

        $product_id = isset($settings['product_id']) ? absint($settings['product_id']) : 0;

        if ($product_id === 0) {
            $product_id = $this->get_current_product_id();
        }

        if ($product_id === 0) {
            return;
        }

        $limit = isset($settings['limit']) ? absint($settings['limit']) : 8;
        $related_ids = self::$related_service->get_related_ids($product_id, $limit);

        if (empty($related_ids)) {
            return;
        }

        $products = Products::get_by_ids($related_ids);

        if (empty($products)) {
            return;
        }

        $title = isset($settings['title']) ? $settings['title'] : '';
        $layout = isset($settings['layout']) ? $settings['layout'] : 'grid';
        $columns = isset($settings['columns']) ? absint($settings['columns']) : 4;
        $show_price = isset($settings['show_price']) ? (bool) $settings['show_price'] : true;
        $show_add_to_cart = isset($settings['show_add_to_cart']) ? (bool) $settings['show_add_to_cart'] : true;

        $wrapper_classes = ['fflu-bricks-element', 'fflu-layout-' . $layout];

        echo '<div ' . $this->render_attributes('_root') . ' class="' . esc_attr(implode(' ', $wrapper_classes)) . '">';

        if ($title) {
            echo '<h3 class="fflu-title">' . esc_html($title) . '</h3>';
        }

        $products_classes = ['fflu-bricks-products'];

        if ($layout === 'grid') {
            $products_classes[] = 'fflu-grid-columns-' . $columns;
        }

        echo '<div class="' . esc_attr(implode(' ', $products_classes)) . '">';

        global $product;
        $original_product = $product;

        foreach ($products as $loop_product) {
            $product = $loop_product;

            echo '<div class="fflu-product-item">';
            echo '<a href="' . esc_url($loop_product->get_permalink()) . '" class="fflu-product-link">';

            if ($loop_product->get_image_id()) {
                echo '<div class="fflu-product-image">';
                echo wp_kses_post($loop_product->get_image('woocommerce_thumbnail'));
                echo '</div>';
            }

            echo '<h4 class="fflu-product-name">' . esc_html($loop_product->get_name()) . '</h4>';

            if ($show_price) {
                echo '<div class="fflu-product-price">' . wp_kses_post($loop_product->get_price_html()) . '</div>';
            }

            echo '</a>';

            if ($show_add_to_cart) {
                echo '<div class="fflu-product-add-to-cart">';
                woocommerce_template_loop_add_to_cart(['product' => $loop_product]);
                echo '</div>';
            }

            echo '</div>';
        }

        $product = $original_product;

        echo '</div>';
        echo '</div>';
    }

    private function get_current_product_id(): int {
        global $product, $post;

        if ($product && is_a($product, 'WC_Product')) {
            return $product->get_id();
        }

        if ($post && $post->post_type === 'product') {
            return $post->ID;
        }

        if (is_singular('product')) {
            return get_the_ID();
        }

        return 0;
    }
}
