<?php

namespace FFL\Upsell\Helpers;

defined('ABSPATH') || exit;

class Cache {
    private static array $object_cache_keys = [];

    public static function get(string $key) {
        if (wp_using_ext_object_cache()) {
            return wp_cache_get($key, 'fflu');
        }

        return get_transient($key);
    }

    public static function set(string $key, $value, int $expiration = 0): bool {
        if (wp_using_ext_object_cache()) {
            self::$object_cache_keys[$key] = true;
            return wp_cache_set($key, $value, 'fflu', $expiration);
        }

        return set_transient($key, $value, $expiration);
    }

    public static function delete(string $key): bool {
        if (wp_using_ext_object_cache()) {
            unset(self::$object_cache_keys[$key]);
            return wp_cache_delete($key, 'fflu');
        }

        return delete_transient($key);
    }

    public static function delete_by_prefix(string $prefix): int {
        $deleted = 0;

        if (wp_using_ext_object_cache()) {
            if (function_exists('wp_cache_flush_group')) {
                wp_cache_flush_group('fflu');
                self::$object_cache_keys = [];
                return -1;
            }

            foreach (array_keys(self::$object_cache_keys) as $key) {
                if (strpos($key, $prefix) === 0) {
                    wp_cache_delete($key, 'fflu');
                    unset(self::$object_cache_keys[$key]);
                    $deleted++;
                }
            }
        }

        global $wpdb;
        $like_pattern = '_transient_' . $wpdb->esc_like($prefix) . '%';
        $timeout_pattern = '_transient_timeout_' . $wpdb->esc_like($prefix) . '%';

        $deleted += (int) $wpdb->query(
            $wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like_pattern)
        );
        $wpdb->query(
            $wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $timeout_pattern)
        );

        return $deleted;
    }

    public static function flush(): void {
        if (wp_using_ext_object_cache()) {
            if (function_exists('wp_cache_flush_group')) {
                wp_cache_flush_group('fflu');
            } else {
                foreach (array_keys(self::$object_cache_keys) as $key) {
                    wp_cache_delete($key, 'fflu');
                }
            }
            self::$object_cache_keys = [];
        }

        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_fflu_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_fflu_%'");
    }
}
