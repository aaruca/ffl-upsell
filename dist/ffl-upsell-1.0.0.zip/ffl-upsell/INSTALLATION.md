# FFL Upsell - Guía de Instalación

## Instalación Rápida

### Método 1: Subir ZIP a WordPress

1. **Crear el archivo ZIP del plugin:**
   ```bash
   cd "/Users/alearuca/Cloud-Drive/Trabajo/My Plugins"
   zip -r ffl-upsell.zip "FFL Upsell" -x "*.git*" "*.DS_Store" "node_modules/*"
   ```

2. **Subir a WordPress:**
   - Ve a `Plugins > Añadir nuevo > Subir plugin`
   - Selecciona el archivo `ffl-upsell.zip`
   - Haz clic en "Instalar ahora"
   - Activa el plugin

### Método 2: Subir vía FTP/SFTP

1. **Sube la carpeta completa:**
   - Sube toda la carpeta `FFL Upsell` a `/wp-content/plugins/`
   - Asegúrate de que se llame `FFL Upsell` o `ffl-upsell`

2. **Activa el plugin:**
   - Ve a `Plugins` en WordPress
   - Busca "FFL Upsell"
   - Haz clic en "Activar"

## Requisitos del Sistema

- **WordPress:** 6.0 o superior
- **WooCommerce:** 7.0 o superior
- **PHP:** 8.0 o superior
- **MySQL:** 5.7 o superior

## Verificación Post-Instalación

1. **Verifica que la tabla se haya creado:**
   - Ve a `phpMyAdmin` o tu gestor de base de datos
   - Busca la tabla `wp_ffl_related` (o con tu prefijo de BD)

2. **Ejecuta el primer rebuild:**
   - Ve a `WooCommerce > FFL Upsell > Tools`
   - Haz clic en "Rebuild All Relations"
   - Espera a que termine (puedes ver el progreso en los logs)

3. **Verifica el shortcode:**
   ```
   [ffl_related_products]
   ```
   Añádelo a una página de producto para probar

## Configuración Inicial Recomendada

1. **Ajusta los pesos de scoring:**
   - Ve a `WooCommerce > FFL Upsell > Settings`
   - `Category/Tag Weight`: 0.6 (default)
   - `Co-occurrence Weight`: 0.4 (default)

2. **Configura el cron (opcional pero recomendado):**
   - Los rebuilds automáticos se ejecutan diariamente
   - Puedes ajustar la frecuencia en Settings

3. **Cache (si usas Redis/Memcached):**
   - El plugin detectará automáticamente object cache externo
   - Las claves se guardan en el grupo `fflu`

## Solución de Problemas

### Error: "ffl_related table does not exist"
**Causa:** La tabla no se creó durante la activación.

**Solución:**
```php
// Desactiva y reactiva el plugin
// O ejecuta manualmente en Tools > Rebuild All
```

### Error: "WooCommerce order product lookup table not found"
**Causa:** WooCommerce no tiene habilitadas las Analytics Tables.

**Solución:**
- El plugin funcionará solo con taxonomías (categorías/tags)
- Para habilitar co-occurrence, ve a `WooCommerce > Settings > Advanced > Features`
- Activa "Analytics" y ejecuta la migración de datos

### El shortcode no muestra productos
**Causa:** No se ha ejecutado ningún rebuild.

**Solución:**
```bash
# Vía WP-CLI
wp fflu rebuild all

# O desde admin
WooCommerce > FFL Upsell > Tools > Rebuild All Relations
```

## Comandos WP-CLI (Opcional)

Si tienes WP-CLI instalado:

```bash
# Rebuild completo
wp fflu rebuild all

# Rebuild de un solo producto
wp fflu rebuild single 123

# Ver stats
wp fflu stats

# Limpiar cache
wp fflu cache flush
```

## Desinstalación Limpia

Para eliminar completamente el plugin y sus datos:

1. Edita `ffl-upsell.php` y cambia:
   ```php
   define('FFL_UPSELL_DROP_TABLE_ON_UNINSTALL', true);
   ```

2. Desinstala el plugin desde WordPress

**Advertencia:** Esto eliminará la tabla `wp_ffl_related` y todas las relaciones calculadas.

## Soporte

- **Issues:** https://github.com/alearuca/ffl-upsell/issues
- **Email:** ale@alearuca.com
